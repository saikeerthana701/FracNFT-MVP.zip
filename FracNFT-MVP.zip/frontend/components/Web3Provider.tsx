"use client";
import {createContext,useContext,useEffect,useState} from "react";
import {ethers} from "ethers";
import {chainId} from "@/lib/web3";
type C={account:string;provider:ethers.BrowserProvider|null;connect:()=>Promise<void>;disconnect:()=>void;wrongNetwork:boolean};
const Ctx=createContext<C>({account:"",provider:null,connect:async()=>{},disconnect:()=>{},wrongNetwork:false});
export function Web3Provider({children}:{children:React.ReactNode}){const [account,setAccount]=useState("");const [provider,setProvider]=useState<ethers.BrowserProvider|null>(null);const [wrongNetwork,setWrong]=useState(false);const connect=async()=>{if(!(window as any).ethereum) throw new Error("Install MetaMask");const p=new ethers.BrowserProvider((window as any).ethereum);await p.send("eth_requestAccounts",[]);const n=await p.getNetwork();setWrong(n.chainId!==chainId);const s=await p.getSigner();setAccount(await s.getAddress());setProvider(p)};useEffect(()=>{const e=(window as any).ethereum;if(!e)return;const onA=(a:string[])=>a.length?connect():setAccount("");const onC=()=>connect();e.on?.("accountsChanged",onA);e.on?.("chainChanged",onC);return()=>{e.removeListener?.("accountsChanged",onA);e.removeListener?.("chainChanged",onC)}} ,[]);return <Ctx.Provider value={{account,provider,connect,disconnect:()=>setAccount(""),wrongNetwork}}>{children}</Ctx.Provider>}
export const useWeb3=()=>useContext(Ctx);
