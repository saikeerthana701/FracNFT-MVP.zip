import "./globals.css";import Navbar from "@/components/Navbar";import {Web3Provider} from "@/components/Web3Provider";
export default function RootLayout({children}:{children:React.ReactNode}){return <html><body className="gradient min-h-screen"><Web3Provider><Navbar/><main className="mx-auto max-w-7xl px-4 py-8">{children}</main></Web3Provider></body></html>}
