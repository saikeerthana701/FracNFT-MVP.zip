import {ethers} from "ethers";
export const chainId=BigInt(process.env.NEXT_PUBLIC_CHAIN_ID||"31337");
export const vaultAddress=process.env.NEXT_PUBLIC_VAULT_CONTRACT||"";
export const nftAddress=process.env.NEXT_PUBLIC_NFT_CONTRACT||"";
export function getBrowserProvider(){ if(typeof window==="undefined" || !(window as any).ethereum) throw new Error("MetaMask is not installed"); return new ethers.BrowserProvider((window as any).ethereum); }
export async function getSigner(){const p=getBrowserProvider();return p.getSigner()}
export function shortAddress(a:string){return a?`${a.slice(0,6)}...${a.slice(-4)}`:"—"}
export function stateLabel(s:number){return ["ACTIVE","BUYOUT_PENDING","COMPLETED"][s]||"UNKNOWN"}
