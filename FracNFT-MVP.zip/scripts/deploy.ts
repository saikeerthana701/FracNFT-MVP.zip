import { ethers } from "hardhat";
import fs from "node:fs";
import path from "node:path";
async function main() {
  const [deployer] = await ethers.getSigners();
  const NFT = await ethers.getContractFactory("TestNFT");
  const nft = await NFT.deploy(); await nft.waitForDeployment();
  const Vault = await ethers.getContractFactory("FractionalNFTVault");
  const vault = await Vault.deploy(deployer.address); await vault.waitForDeployment();
  const out = { chainId: (await ethers.provider.getNetwork()).chainId.toString(), nft: await nft.getAddress(), vault: await vault.getAddress(), deployer: deployer.address };
  fs.writeFileSync(path.join(process.cwd(), "deployments.json"), JSON.stringify(out, null, 2));
  console.log(out);
}
main().catch(e => { console.error(e); process.exit(1); });
