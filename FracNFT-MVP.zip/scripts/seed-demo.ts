import { ethers } from "hardhat";
import fs from "node:fs";
async function main() {
  const [alice,bob,charlie] = await ethers.getSigners();
  const d = JSON.parse(fs.readFileSync("deployments.json","utf8"));
  const nft = await ethers.getContractAt("TestNFT", d.nft);
  const vault = await ethers.getContractAt("FractionalNFTVault", d.vault);
  const mintTx = await nft.mint(alice.address, "https://example.com/fracnft/demo-001.json"); await mintTx.wait();
  const approve = await nft.connect(alice).approve(d.vault, 1); await approve.wait();
  const dep = await vault.connect(alice).depositNFT(d.nft, 1, "Digital Artwork #001 Shares", "DA001"); const receipt = await dep.wait();
  const vd = await vault.vault(); const shares = await ethers.getContractAt("ShareToken", vd.shareToken);
  await shares.connect(alice).transfer(bob.address, ethers.parseEther("35"));
  await shares.connect(alice).transfer(charlie.address, ethers.parseEther("25"));
  console.log({tokenId:1, shareToken:vd.shareToken, alice:await shares.balanceOf(alice.address), bob:await shares.balanceOf(bob.address), charlie:await shares.balanceOf(charlie.address), depositBlock:receipt?.blockNumber});
}
main().catch(e=>{console.error(e);process.exit(1)});
