# FracNFT — Fractional NFT Ownership MVP

A real EVM MVP for locking one ERC-721 inside a vault, issuing exactly 100 ERC-20 ownership shares, transferring those shares, funding a complete-NFT buyout, transferring the NFT to the buyer, and allowing shareholders to claim proportional ETH proceeds.

## Architecture

- `contracts/TestNFT.sol` — owner-mintable demo ERC-721.
- `contracts/ShareToken.sol` — exactly 100 ERC-20 shares. Transfers are frozen when a buyout completes so the claim entitlement cannot be changed after completion.
- `contracts/FractionalNFTVault.sol` — NFT custody, fractionalization, buyout state machine, proportional claims and reentrancy protection.
- `frontend/` — Next.js + TypeScript + Tailwind + ethers.js Web3 dashboard.
- `backend/` — Express + SQLite event indexer. Blockchain state remains authoritative.
- `test/` — Hardhat tests for custody, shares, buyout, claims, access control and state transitions.

## Important MVP governance decision

A buyout is funded by any wallet, but the **original NFT depositor is the vault curator and must finalize the offer**. This is an explicit MVP rule because the supplied specification requires an offer/accept/finalize workflow but does not define shareholder voting. A production version should replace this with a formal governance/quorum mechanism.

## Local setup

### 1. Install

```bash
npm install
npm install --workspace frontend
npm install --workspace backend
```

### 2. Compile and test

```bash
cp .env.example .env
npm run compile
npm test
```

### 3. Start a local blockchain

Terminal A:

```bash
npm run chain
```

The Hardhat node exposes chain ID `31337` at `http://127.0.0.1:8545`.

Import one of the displayed Hardhat test accounts into MetaMask using its **private key printed by the local node**. Never use these development keys on a real network.

### 4. Deploy

Terminal B:

```bash
npm run deploy
```

This creates `deployments.json` with the NFT and vault addresses.

Set the addresses in `.env`:

```env
NEXT_PUBLIC_NFT_CONTRACT=<TestNFT address>
NEXT_PUBLIC_VAULT_CONTRACT=<FractionalNFTVault address>
```

### 5. Optional seed

The seed script mints token #1, approves the vault, deposits it, creates 100 shares and distributes them:

- deployer/Alice = 40
- Bob = 35
- Charlie = 25

```bash
npm run seed
```

### 6. Start backend

Terminal C:

```bash
npm run backend
```

API: `http://localhost:4000`.

### 7. Start frontend

Terminal D:

```bash
npm run dev
```

Open the Next.js URL shown by the terminal, connect MetaMask, and use the Demo Setup controls.

## End-to-end demo

1. Connect the deployer wallet.
2. Mint Test NFT #1.
3. Approve + lock it in the vault.
4. The vault deploys a ShareToken with exactly `100e18` ERC-20 units, representing 100 whole shares.
5. Transfer 35 shares to Bob and 25 to Charlie to reach 40/35/25.
6. From another wallet, submit a 10 ETH buyout offer.
7. From the original depositor wallet, finalize the offer.
8. The vault transfers the NFT to the buyer and freezes share transfers.
9. Alice/Bob/Charlie claim 4 / 3.5 / 2.5 ETH respectively.
10. A second claim from the same address reverts.

## Security notes

- Solidity uses integer arithmetic only.
- OpenZeppelin ERC-721/ERC-20/Ownable/ReentrancyGuard are used.
- NFT custody uses `safeTransferFrom` and an ERC-721 receiver.
- Claim state is written before the external ETH transfer.
- Share transfers are frozen at buyout completion.
- There is no NFT withdrawal path while active.
- The vault rejects direct ETH transfers; buyout funds must enter through `proposeBuyout`.
- Private keys and seed phrases are never stored by the app.

## Production extensions

For a mainnet-ready version, add audited deployment, multisig administration, shareholder governance, buyout expiry/cancellation, oracle/market pricing if desired, a durable event cursor with reorg handling, IPFS/Arweave metadata validation, database migrations, rate limiting/authentication for non-chain metadata APIs, monitoring, and a full security audit.
