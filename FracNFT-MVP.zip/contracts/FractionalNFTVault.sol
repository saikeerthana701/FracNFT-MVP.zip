// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC721} from "@openzeppelin/contracts/token/ERC721/IERC721.sol";
import {IERC721Receiver} from "@openzeppelin/contracts/token/ERC721/IERC721Receiver.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {ShareToken} from "./ShareToken.sol";

contract FractionalNFTVault is IERC721Receiver, ReentrancyGuard, Ownable {
    enum VaultState { ACTIVE, BUYOUT_PENDING, COMPLETED }
    struct VaultData { address nft; uint256 tokenId; address depositor; address shareToken; uint256 totalShares; VaultState state; address buyer; uint256 buyoutAmount; uint256 buyoutAt; }

    uint256 public constant SHARES = 100;
    uint256 public constant MIN_BUYOUT = 1 wei;
    VaultData public vault;
    mapping(address => bool) public claimed;
    mapping(address => uint256) public claimedAmount;

    event NFTDeposited(address indexed nft, uint256 indexed tokenId, address indexed depositor, address shareToken);
    event SharesCreated(address indexed shareToken, uint256 totalShares);
    event BuyoutProposed(address indexed buyer, uint256 amount, uint256 timestamp);
    event BuyoutFinalized(address indexed buyer, uint256 amount, uint256 timestamp);
    event NFTTransferred(address indexed buyer);
    event ProceedsClaimed(address indexed shareholder, uint256 shares, uint256 amount);

    error InvalidState(); error InvalidAmount(); error AlreadyClaimed(); error NoShares(); error NotDepositor(); error NFTNotInVault();

    constructor(address admin) Ownable(admin) {}

    function depositNFT(address nft, uint256 tokenId, string calldata shareName, string calldata shareSymbol) external nonReentrant {
        if (vault.state != VaultState.ACTIVE || vault.nft != address(0)) revert InvalidState();
        IERC721(nft).safeTransferFrom(msg.sender, address(this), tokenId);
        ShareToken shares = new ShareToken(address(this), msg.sender, shareName, shareSymbol);
        vault = VaultData(nft, tokenId, msg.sender, address(shares), SHARES, VaultState.ACTIVE, address(0), 0, 0);
        emit NFTDeposited(nft, tokenId, msg.sender, address(shares));
        emit SharesCreated(address(shares), SHARES);
    }

    function proposeBuyout() external payable nonReentrant {
        if (vault.state != VaultState.ACTIVE) revert InvalidState();
        if (msg.value < MIN_BUYOUT) revert InvalidAmount();
        vault.state = VaultState.BUYOUT_PENDING;
        vault.buyer = msg.sender;
        vault.buyoutAmount = msg.value;
        vault.buyoutAt = block.timestamp;
        emit BuyoutProposed(msg.sender, msg.value, block.timestamp);
    }

    // MVP governance: the original depositor acts as the vault curator and accepts an offer.
    function finalizeBuyout() external nonReentrant {
        if (vault.state != VaultState.BUYOUT_PENDING) revert InvalidState();
        if (msg.sender != vault.depositor) revert NotDepositor();
        vault.state = VaultState.COMPLETED;
        ShareToken(vault.shareToken).lockTransfers();
        IERC721(vault.nft).safeTransferFrom(address(this), vault.buyer, vault.tokenId);
        emit BuyoutFinalized(vault.buyer, vault.buyoutAmount, block.timestamp);
        emit NFTTransferred(vault.buyer);
    }

    function claimProceeds() external nonReentrant {
        if (vault.state != VaultState.COMPLETED) revert InvalidState();
        if (claimed[msg.sender]) revert AlreadyClaimed();
        uint256 rawShares = ShareToken(vault.shareToken).balanceOf(msg.sender);
        if (rawShares == 0) revert NoShares();
        uint256 amount = (vault.buyoutAmount * rawShares) / ShareToken(vault.shareToken).totalSupply();
        claimed[msg.sender] = true;
        claimedAmount[msg.sender] = amount;
        (bool ok,) = payable(msg.sender).call{value: amount}("");
        require(ok, "ETH transfer failed");
        emit ProceedsClaimed(msg.sender, rawShares, amount);
    }

    function shareBalance(address account) external view returns (uint256) { return ShareToken(vault.shareToken).balanceOf(account); }
    function ownershipBps(address account) external view returns (uint256) {
        if (vault.shareToken == address(0)) return 0;
        return (ShareToken(vault.shareToken).balanceOf(account) * 10000) / ShareToken(vault.shareToken).totalSupply();
    }
    function claimable(address account) external view returns (uint256) {
        if (vault.state != VaultState.COMPLETED || claimed[account]) return 0;
        uint256 s = ShareToken(vault.shareToken).balanceOf(account);
        return (vault.buyoutAmount * s) / ShareToken(vault.shareToken).totalSupply();
    }
    function onERC721Received(address, address, uint256, bytes calldata) external pure override returns (bytes4) { return IERC721Receiver.onERC721Received.selector; }
    receive() external payable { revert("Use proposeBuyout"); }
}
