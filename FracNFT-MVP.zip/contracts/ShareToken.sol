// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";

contract ShareToken is ERC20, Ownable {
    uint256 public constant TOTAL_SHARES = 100 ether;
    bool public transfersLocked;

    constructor(address vaultOwner, address recipient, string memory name_, string memory symbol_)
        ERC20(name_, symbol_)
        Ownable(vaultOwner)
    {
        _mint(recipient, TOTAL_SHARES);
    }

    function lockTransfers() external onlyOwner { transfersLocked = true; }

    function _update(address from, address to, uint256 value) internal override {
        if (transfersLocked && from != address(0) && to != address(0)) revert("Share transfers locked");
        super._update(from, to, value);
    }
}
