import { expect } from "chai";
import { ethers } from "hardhat";

describe("FractionalNFTVault", function () {
  async function setup(){
    const [alice,bob,charlie,buyer] = await ethers.getSigners();
    const NFT=await ethers.getContractFactory("TestNFT"); const nft=await NFT.deploy(); await nft.waitForDeployment();
    const Vault=await ethers.getContractFactory("FractionalNFTVault"); const vault=await Vault.deploy(alice.address); await vault.waitForDeployment();
    await nft.mint(alice.address,"ipfs://demo"); await nft.connect(alice).approve(await vault.getAddress(),1);
    await vault.connect(alice).depositNFT(await nft.getAddress(),1,"Demo Shares","DMS");
    const vd=await vault.vault(); const shares=await ethers.getContractAt("ShareToken",vd.shareToken);
    return {alice,bob,charlie,buyer,nft,vault,shares};
  }
  it("locks NFT and creates exactly 100 shares", async()=>{ const {alice,nft,vault,shares}=await setup(); expect(await nft.ownerOf(1)).eq(await vault.getAddress()); expect(await shares.totalSupply()).eq(ethers.parseEther("100")); expect(await shares.balanceOf(alice.address)).eq(ethers.parseEther("100")); });
  it("transfers shares", async()=>{const {alice,bob,charlie,shares}=await setup(); await shares.connect(alice).transfer(bob.address,ethers.parseEther("35")); await shares.connect(alice).transfer(charlie.address,ethers.parseEther("25")); expect(await shares.balanceOf(alice.address)).eq(ethers.parseEther("40"));});
  it("completes buyout and pays proportional claims", async()=>{const {alice,bob,charlie,buyer,nft,vault,shares}=await setup(); await shares.connect(alice).transfer(bob.address,ethers.parseEther("35")); await shares.connect(alice).transfer(charlie.address,ethers.parseEther("25")); const amount=ethers.parseEther("10"); await vault.connect(buyer).proposeBuyout({value:amount}); await vault.connect(alice).finalizeBuyout(); expect(await nft.ownerOf(1)).eq(buyer.address); const before=await ethers.provider.getBalance(bob.address); const tx=await vault.connect(bob).claimProceeds(); const rc=await tx.wait(); const after=await ethers.provider.getBalance(bob.address); expect(after).gt(before); expect(await vault.claimed(bob.address)).true; await expect(vault.connect(bob).claimProceeds()).reverted; });
  it("blocks unauthorized finalization and invalid state", async()=>{const {alice,bob,buyer,vault}=await setup(); await expect(vault.connect(alice).finalizeBuyout()).reverted; await vault.connect(buyer).proposeBuyout({value:ethers.parseEther("1")}); await expect(vault.connect(bob).finalizeBuyout()).reverted; await vault.connect(alice).finalizeBuyout(); await expect(vault.connect(buyer).proposeBuyout({value:1})).reverted;});
});
